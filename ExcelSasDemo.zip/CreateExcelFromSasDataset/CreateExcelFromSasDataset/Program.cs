﻿using OfficeOpenXml;
using System;
using System.Data;
using System.Data.OleDb;
using System.IO;

namespace CreateExcelFromSasDataset
{
    class Program
    {
        static string _outName = "TEST";

        static void Main(string[] args)
        {
            Console.WriteLine("Create an Excel file from a SAS dataset");
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            var dt = GetSasDataSet(@"x:\temp","shoes");
            CreateExcelWorksheet(dt);
            Console.WriteLine("Excel workbook created. Press any key...");
            Console.ReadKey();
        }

        /// <summary>
        /// Gets a SAS dataset from the specified location
        /// </summary>
        /// <param name="sasLibrary">The physical location of the SAS library to read in the data </param>
        /// <param name="dataset">The name of the SAS dataset to read</param>
        /// <returns>.NET datatable</returns>
        public static DataTable GetSasDataSet(string sasLibrary, string dataset)
        {
            OleDbConnection sas = null;
            DataTable dt = new DataTable(dataset);
            try
            {
                sas = new OleDbConnection(@"Provider=SAS.LocalProvider.1; Data Source=" + sasLibrary);
                sas.Open();
                OleDbCommand sasCommand = sas.CreateCommand();
                sasCommand.CommandType = CommandType.TableDirect;
                sasCommand.CommandText = dataset;
                OleDbDataReader sasRead = sasCommand.ExecuteReader();
                dt.Load(sasRead);
                sas.Close();
            }
            catch (Exception ex)
            {
                sas.Close();
                string errMessage = "Unable to get the SAS dataset. Library: " + sasLibrary + ", DataSet: " + dataset + ", " +
                    ex.TargetSite.Name;
                throw ex;
            }
            finally
            {
                sas.Close();
            }
            return dt;
        }


        private static void CreateExcelWorksheet(DataTable dt)
        {
            var ExcelPkg = new ExcelPackage();
            var wsSheet1 = ExcelPkg.Workbook.Worksheets.Add("Sheet1");
            using (var rng = wsSheet1.Cells[2, 2, 2, 2])
            {
                rng.Value = "My first SAS Excel worksheet";
                rng.Style.Font.Size = 16;
                rng.Style.Font.Bold = true;
                rng.Style.Font.Italic = true;
            }

            //Careful here since EPPlus uses 1 based arrays for cells and .NET is 0 based
            int row = 4;
            int col = 1;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                col = 1;
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    wsSheet1.Cells[row, col++].Value = dt.Rows[i][j].ToString();
                }
                row++;
            }
            wsSheet1.Protection.IsProtected = false;
            wsSheet1.Protection.AllowSelectLockedCells = false;
            ExcelPkg.SaveAs(new FileInfo($@"c:\temp\{_outName}.xlsx"));
        }
    }
}
